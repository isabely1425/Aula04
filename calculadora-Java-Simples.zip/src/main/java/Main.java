import java.util.Scanner;

public class Main{
  public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);

    Double num1;
    Double num2;  
    String operacao;

    System.out.println("Digite o primeiro número: ");
    num1 = scanner.nextDouble();

    System.out.println("Digite a operação (+, -, /, *");
    operacao = scanner.next();

    System.out.println("Digite o segundo número: ");
    num2 = scanner.nextDouble();

    //Realizado a operacao escolhida pelo metado calculo
    System.out.println("Resultado: " + calculo(num1, operacao, num2));

    Scanner.close();
  }

  public static double calculo(double num1, String operacao, double num2){
    double resultado = 0;

    if(operacao.equals("+")){
      resultado = num1 + num2;
    }else if(operacao.equals("-")){
      resultado = num1 - num2;
    }else if(operacao.equals("/")){
      resultado = num1 / num2;
    }else if(operacao.equals("*")){
      resultado = num1 * num2;
    }
  

    return resultado;
  }
}